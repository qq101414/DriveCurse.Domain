﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Centa.ZJ.DriveCurse.Application.Interface.Sys
{
    public interface IEmployeeService
    {
        void AddEmployeeInfo();
    }
}
