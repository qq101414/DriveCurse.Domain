﻿using Centa.ZJ.DriveCurse.Application.Interface.Sys;
using Centa.ZJ.DriveCurse.Domain.Core;
using Centa.ZJ.DriveCurse.Domain.Sys;
using System;
using System.Collections.Generic;
using System.Text;

namespace Centa.ZJ.DriveCurse.Application.Sys
{
    public class EmployeeService : IEmployeeService
    {
        private IEmployeeRepository _employeeRepository;
        private IUnitOfWork unitOfWork;
        public EmployeeService(IEmployeeRepository employeeRepository, IUnitOfWork unitOfWork)
        {
            this._employeeRepository = employeeRepository;
            this.unitOfWork = unitOfWork;
        }


        public void AddEmployeeInfo()
        {
            var newEmployee = SysFactory.NewEmployee();
            newEmployee.SetAge(24);
            newEmployee.SetEmployeeNo("ZJ10092");
            newEmployee.SetCardNo("411424199408044551");
            newEmployee.SetName("宋梦辉");
            newEmployee.SetSex("男");
            _employeeRepository.Add(newEmployee);
            //this.unitOfWork.RegisterNew(newEmployee);
            this.unitOfWork.Commit();
        }


    }
}
