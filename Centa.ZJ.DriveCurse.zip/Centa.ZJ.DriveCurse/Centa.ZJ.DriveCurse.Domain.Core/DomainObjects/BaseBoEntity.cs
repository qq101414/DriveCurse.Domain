﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Centa.ZJ.DriveCurse.Domain.Core.DomainObjects
{
    /// <summary>
    /// 领域层实体-聚合根继承
    /// 用来约束聚合根实体
    /// </summary>
    public abstract class BaseBoEntity : BaseEntity
    {
        /// <summary>
        /// 创建时间
        /// </summary>
        public DateTime? CreateTime { get; set; }


    }
}
