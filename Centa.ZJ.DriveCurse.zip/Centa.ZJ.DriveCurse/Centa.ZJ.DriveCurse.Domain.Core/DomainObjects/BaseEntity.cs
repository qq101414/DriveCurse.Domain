﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Centa.ZJ.DriveCurse.Domain.Core.DomainObjects
{
    public abstract class BaseEntity
    {
        [Key]
        public Guid KeyId { get; set; }

    }
}
