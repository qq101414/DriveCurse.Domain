﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Centa.ZJ.DriveCurse.Domain.Core.DomainObjects
{
    /// <summary>
    /// 领域业务对象基类
    /// </summary>
    public abstract class BaseObjects
    {
        /// <summary>
        ///  数据存储对象，是业务对象的数据库映射
        /// </summary>
        public BaseEntity Entity;

        /// <summary>
        /// keyId-数据库存储唯一
        /// </summary>
        protected Guid KeyId { get => this.Entity.KeyId; set => this.Entity.KeyId = value; }

        /// <summary>
        /// 获取数据库存储对象Id
        /// </summary>
        /// <returns></returns>
        public Guid GetKeyId()
        {
            return this.Entity.KeyId;
        }
        /// <summary>
        /// 获取领域业务对象的实体对象。只允许Internal被Repository的基类实现调用。
        /// </summary>
        /// <returns></returns>
        internal BaseBoEntity GetEntity()
        {
            return (BaseBoEntity)this.Entity;
        }
    }
}
