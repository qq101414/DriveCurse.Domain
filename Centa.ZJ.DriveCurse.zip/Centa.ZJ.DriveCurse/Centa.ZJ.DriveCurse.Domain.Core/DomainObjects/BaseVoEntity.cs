﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Centa.ZJ.DriveCurse.Domain.Core.DomainObjects
{
    /// <summary>
    /// 用来约束非聚合实体
    /// </summary>
    public abstract class BaseVoEntity : BaseEntity
    {
    }
}
