﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace Centa.ZJ.DriveCurse.Domain.Core
{
    public interface IBaseRepository<IEntity, SearchCriteriaT, SortCriteriaT>
    {
        /// <summary>
        /// 把一个新建的业务对象交给Repository管理
        /// </summary>
        /// <param name="item">新建的业务对象</param>
        void Add(IEntity bo);

        /// <summary>
        /// 把指定的业务对象从repository中删除
        /// </summary>
        /// <param name="item">需要被删除的业务对象</param>
        void Remove(IEntity bo);

        /// <summary>
        /// 根据keyId寻找业务对象
        /// </summary>
        /// <returns>KeyId所对应的业务对象，或者NULL</returns>
        IEntity Find(Guid keyId);

        /// <summary>
        /// 根据给定的搜索条件寻找业务对象
        /// </summary>
        /// <param name="SearchCriteria">搜索条件</param>
        /// <returns>业务对象列表</returns>
        List<IEntity> FindByCondition(SearchCriteriaT searchCriteria);

        /// <summary>
        /// 根据给定的搜索条件寻找业务对象，返回列表按照给定的方式排序
        /// </summary>
        /// <param name="searchCriteria">搜索条件</param>
        /// <param name="sortCriteria">排序方式</param>
        /// <returns></returns>
        List<IEntity> FindByCondition(SearchCriteriaT searchCriteria, SortCriteriaT sortCriteria);

        /// <summary>
        /// 根据给定的搜索条件寻找业务对象，支持Paging功能和非Paging功能
        /// </summary>
        /// <param name="searchCriteria">搜索条件</param>
        /// <param name="sortCriteria">排序方式</param>
        /// <param name="pageIndex">页码号，从1开始</param>
        /// <param name="pageSize">每页的对象个数</param>
        /// <returns></returns>
        List<IEntity> FindPagedByCondition(SearchCriteriaT searchCriteria, SortCriteriaT sortCriteria, int? pageIndex = null, int? pageSize = null);

        /// <summary>
        /// 返回满足搜寻条件的业务对象的数目
        /// </summary>
        /// <param name="searchCriteria"></param>
        /// <returns></returns>
        int CountByCondition(SearchCriteriaT searchCriteria);

        /// <summary>
        /// 返回所有业务对象的数目 
        /// </summary>
        /// <returns></returns>
        int CountAll();

        /// <summary>
        /// 寻找所有业务对象
        /// </summary>
        /// <returns></returns>
        List<IEntity> FindAll();

        /// <summary>
        /// 寻找所有业务对象，返回列表按照给定的方式排序
        /// </summary>
        /// <param name="sortCriteria">排序方式</param>
        /// <returns></returns>
        List<IEntity> FindAll(SortCriteriaT sortCriteria);

        /// <summary>
        /// 寻找所有业务对象，支持Paging功能
        /// </summary>
        /// <param name="sortCriteria">排序方式</param>
        /// <param name="pageIndex">页码号，从1开始</param>
        /// <param name="pageSize">每页的对象个数</param>
        /// <returns></returns>
        List<IEntity> FindPagedAll(SortCriteriaT sortCriteria, int pageIndex, int pageSize);
        /// <summary>
        /// 根据dt数据表 直接拷贝到数据库
        /// </summary>
        /// <param name="dt">DataTable</param>
        /// <param name="tableName">表名</param>
        void BulkInsert(DataTable dt, string tableName);
    }
}
