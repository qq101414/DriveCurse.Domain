﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace Centa.ZJ.DriveCurse.Domain.Core
{
    /// <summary>
    /// 实现EF映射关系
    /// </summary>
    public interface IOnModelCreating
    {
        /// <summary>
        /// 实体映射关系
        /// </summary>
        /// <param name="modelBuilder"></param>
        void OnModelCreating(ModelBuilder modelBuilder);
    }
}
