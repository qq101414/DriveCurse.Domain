﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Centa.ZJ.DriveCurse.Domain.Core.Migrations
{
    public partial class init : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "EmployeePermission",
                columns: table => new
                {
                    KeyId = table.Column<Guid>(nullable: false),
                    CreateTime = table.Column<DateTime>(nullable: false),
                    Land = table.Column<bool>(nullable: false),
                    EmoloyeeKeyId = table.Column<Guid>(nullable: true),
                    EmployeeKeyId = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EmployeePermission", x => x.KeyId);
                });

            migrationBuilder.CreateTable(
                name: "Employee",
                columns: table => new
                {
                    KeyId = table.Column<Guid>(nullable: false),
                    CreateTime = table.Column<DateTime>(nullable: false),
                    Name = table.Column<string>(maxLength: 10, nullable: false),
                    EmployeeNo = table.Column<string>(nullable: false),
                    Sex = table.Column<string>(maxLength: 4, nullable: true),
                    Age = table.Column<int>(maxLength: 3, nullable: false),
                    CardNo = table.Column<string>(nullable: false),
                    PermissionKeyId = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Employee", x => x.KeyId);
                    table.ForeignKey(
                        name: "FK_Employee_EmployeePermission_PermissionKeyId",
                        column: x => x.PermissionKeyId,
                        principalTable: "EmployeePermission",
                        principalColumn: "KeyId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Employee_PermissionKeyId",
                table: "Employee",
                column: "PermissionKeyId");

            migrationBuilder.CreateIndex(
                name: "IX_EmployeePermission_EmployeeKeyId",
                table: "EmployeePermission",
                column: "EmployeeKeyId");

            migrationBuilder.AddForeignKey(
                name: "FK_EmployeePermission_Employee_EmployeeKeyId",
                table: "EmployeePermission",
                column: "EmployeeKeyId",
                principalTable: "Employee",
                principalColumn: "KeyId",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Employee_EmployeePermission_PermissionKeyId",
                table: "Employee");

            migrationBuilder.DropTable(
                name: "EmployeePermission");

            migrationBuilder.DropTable(
                name: "Employee");
        }
    }
}
