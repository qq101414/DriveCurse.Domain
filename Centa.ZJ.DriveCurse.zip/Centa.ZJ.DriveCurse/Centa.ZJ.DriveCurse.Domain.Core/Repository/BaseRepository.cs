﻿using Centa.ZJ.DriveCurse.Domain.Core.DomainObjects;
using Centa.ZJ.DriveCurse.Library;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace Centa.ZJ.DriveCurse.Domain.Core.Repository
{
    /// <summary>
    /// 仓储实现接口
    /// </summary>
    /// <typeparam name="IEntity">领域对象</typeparam>
    /// <typeparam name="BoEntity">领域实体基类</typeparam>
    /// <typeparam name="SearchCriteriaT">查询接口</typeparam>
    /// <typeparam name="SortCriteriaT">排序</typeparam>
    public abstract class BaseRepository<IEntity, BoEntity, SearchCriteriaT, SortCriteriaT> : IBaseRepository<IEntity, SearchCriteriaT, SortCriteriaT>
        where IEntity : BaseObjects
        where BoEntity : BaseBoEntity
        where SearchCriteriaT : BoSearchCriteria
        where SortCriteriaT : BoSortCriteria

    {
        protected IDbContext _dbContext;
        protected BaseRepository(IDbContext dbContext)
        {
            this._dbContext = dbContext;
        }

        public BaseRepository()
        {
           //_dbContext = AutofacBuild.Resolve<IDbContext>();

        }
        public void Add(IEntity bo)
        {
            var baseBo = bo.GetEntity();//获取领域实体
            baseBo.CreateTime = DateTime.Now;
            this.CreateSet().Add((BoEntity)baseBo);
        }

        public void BulkInsert(DataTable dt, string tableName)
        {
            throw new NotImplementedException();
        }

        public int CountAll()
        {
            throw new NotImplementedException();
        }

        public int CountByCondition(SearchCriteriaT searchCriteria)
        {
            throw new NotImplementedException();
        }

        public IEntity Find(Guid keyId)
        {
            var entity = this.CreateSet().FirstOrDefault(x => x.KeyId == keyId);
            return this.Convert(entity);
        }

        public List<IEntity> FindAll()
        {
            return FindByCondition((SearchCriteriaT)null);
        }

        public List<IEntity> FindAll(SortCriteriaT sortCriteria)
        {
            return this.FindByCondition((SearchCriteriaT)null, sortCriteria);
        }

        public List<IEntity> FindByCondition(SearchCriteriaT searchCriteria)
        {
            return new List<IEntity>();
        }

        public List<IEntity> FindByCondition(SearchCriteriaT searchCriteria, SortCriteriaT sortCriteria)
        {
            return new List<IEntity>();
        }

        public List<IEntity> FindPagedAll(SortCriteriaT sortCriteria, int pageIndex, int pageSize)
        {
            return new List<IEntity>();
        }

        public List<IEntity> FindPagedByCondition(SearchCriteriaT searchCriteria, SortCriteriaT sortCriteria, int? pageIndex = null, int? pageSize = null)
        {
            return new List<IEntity>();
        }

        public void Remove(IEntity bo)
        {
            var baseBo = bo.GetEntity();//获取领域实体
            this.CreateSet().Remove((BoEntity)baseBo);
        }

        /// <summary>
        /// 转换实体到对象
        /// </summary>
        public IEntity Convert(BoEntity boEntity)
        {
            IEntity entity = default(IEntity);
            entity.Entity = boEntity;
            return entity;
        }

        /// <summary>
        /// 指定实体
        /// </summary>
        /// <returns></returns>
        private DbSet<BoEntity> CreateSet()
        {
            return _dbContext.Set<BoEntity>();
        }
    }
}
