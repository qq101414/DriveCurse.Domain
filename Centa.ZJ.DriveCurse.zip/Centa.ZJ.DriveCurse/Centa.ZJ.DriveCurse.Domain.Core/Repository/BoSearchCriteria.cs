﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Centa.ZJ.DriveCurse.Domain.Core.Repository
{
    /// <summary>
    /// 搜索业务条件业务基类
    /// </summary>
    public abstract class BoSearchCriteria
    {
        /// <summary>
        /// 包含的KeyId集合
        /// </summary>
        public List<Guid> IncludedKeyIds { set; get; }

        /// <summary>
        /// 包含的KeyId集合表达式
        /// </summary>
        public IQueryable<Guid> IncludesKeyIdsQueryable { set; get; }

        /// <summary>
        /// 不包含的KeyId集合
        /// </summary>
        public List<Guid> ExcludedKeyIds { set; get; }

    }
}
