﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Centa.ZJ.DriveCurse.Domain.Core.Repository
{
    /// <summary>
    /// 查询业务对象 排序基类
    /// </summary>
    public abstract class BoSortCriteria
    {
    }
}
