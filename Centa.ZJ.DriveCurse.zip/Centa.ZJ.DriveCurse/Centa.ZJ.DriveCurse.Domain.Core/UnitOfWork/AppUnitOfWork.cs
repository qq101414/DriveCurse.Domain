﻿using Centa.ZJ.DriveCurse.Library;
using Microsoft.EntityFrameworkCore.Storage;
using System;
using System.Collections.Generic;
using System.Text;

namespace Centa.ZJ.DriveCurse.Domain.Core.UnitOfWork
{
    public class AppUnitOfWork : IUnitOfWork, IDisposable
    {
        public IDbContext _dbContext;
        private IDbContextTransaction _beginTransaction;

        public AppUnitOfWork(IDbContext dbContext)
        {
            this._dbContext = dbContext;
        }
        public AppUnitOfWork()
        {
            this._dbContext = AutofacBuild.Resolve<IDbContext>();
        }

        public bool Commit()
        {
            if (_beginTransaction == null)
            {
                return _dbContext.SaveChanges() > 0;
            }
            _beginTransaction.Commit();
            Dispose();
            return true;
        }

        public void Dispose()
        {
            if (this._beginTransaction != null)
            {
                this._beginTransaction.Dispose();
            }

        }

        public void OpenBeginTransaction()
        {
            this._beginTransaction = _dbContext.Database.BeginTransaction();
        }


        public void Rollback()
        {
            if (this._beginTransaction != null)
            {
                _beginTransaction.Rollback();
                Dispose();
            }

        }
    }
}
