﻿using Centa.ZJ.DriveCurse.Library;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace Centa.ZJ.DriveCurse.Domain.Core.UnitOfWork
{
    /// <summary>
    /// 
    /// </summary>
    public class SqlServerContext : DbContext, IDbContext
    {
        public SqlServerContext(DbContextOptions options) : base(options)
        {

        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            IEnumerable<IOnModelCreating> onModels = AutofacBuild.ResolveAll<IOnModelCreating>();
            foreach (var item in onModels)
            {
                item.OnModelCreating(modelBuilder);
            }
        }

    }
}
