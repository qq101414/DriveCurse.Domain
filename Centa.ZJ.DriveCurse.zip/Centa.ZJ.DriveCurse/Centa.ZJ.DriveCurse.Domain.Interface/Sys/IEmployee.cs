﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Centa.ZJ.DriveCurse.Domain.Interface.Sys
{
    /// <summary>
    /// 员工领域业务接口
    /// </summary>
    public interface IEmployee
    {
    }
}
