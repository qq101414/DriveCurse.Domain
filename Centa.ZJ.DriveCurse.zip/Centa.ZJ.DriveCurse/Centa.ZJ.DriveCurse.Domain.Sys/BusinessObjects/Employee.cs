﻿using Centa.ZJ.DriveCurse.Domain.Core.DomainObjects;
using Centa.ZJ.DriveCurse.Domain.Interface.Sys;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Centa.ZJ.DriveCurse.Domain.Sys.BusinessObjects
{
    /// <summary>
    /// 定义员工领域实体接口
    /// </summary>
    [Table("Employee")]
    public class EmployeeEntity : BaseBoEntity
    {
        /// <summary>
        /// 员工名字
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// 员工编号
        /// </summary>
        public string EmployeeNo { get; set; }

        /// <summary>
        /// 员工性别
        /// </summary>
        public string Sex { get; set; }
        /// <summary>
        /// 员工年龄
        /// </summary>
        public int Age { get; set; }

        /// <summary>
        /// 员工身份证
        /// </summary>
        public string CardNo { get; set; }

        public Guid? PermissionKeyId { get; set; }

        public virtual EmployeePermissionEntity EmployeePermission { get; set; }
    }

    public class Employee : BaseObjects
    {
        /// <summary>
        /// 数据实体
        /// </summary>
        private EmployeeEntity SelfEntity { get => this.Entity as EmployeeEntity; set => this.Entity = value; }

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="entity"></param>
        public Employee(EmployeeEntity entity)
        {
            this.SelfEntity = entity;
        }

        /// <summary>
        /// 设置员工名字
        /// </summary>
        /// <param name="name"></param>
        public void SetName(string name)
        {
            this.SelfEntity.Name = name;
        }
        /// <summary>
        /// 获取数据库名字
        /// </summary>
        /// <returns></returns>
        public string GetName()
        {
            return this.SelfEntity.Name;
        }
        /// <summary>
        /// 设置员工编号
        /// </summary>
        /// <param name="no"></param>
        public void SetEmployeeNo(string no)
        {
            this.SelfEntity.EmployeeNo = no;
        }
        /// <summary>
        /// 获取员工编号
        /// </summary>
        /// <returns></returns>
        public string GetEmployeeNo()
        {
            return this.SelfEntity.EmployeeNo;
        }
        /// <summary>
        /// 设置性别
        /// </summary>
        /// <param name="Sex"></param>
        public void SetSex(string Sex)
        {
            this.SelfEntity.Sex = Sex;
        }
        /// <summary>
        /// 获取性别
        /// </summary>
        /// <returns></returns>
        public string GetSex()
        {
            return this.SelfEntity.Sex;
        }
        /// <summary>
        /// 设置年龄
        /// </summary>
        /// <param name="Age"></param>
        public void SetAge(int Age)
        {
            this.SelfEntity.Age = Age;
        }
        /// <summary>
        /// 返回年龄
        /// </summary>
        /// <returns></returns>
        public int GetAge()
        {
            return this.SelfEntity.Age;
        }
        /// <summary>
        /// 设置身份证
        /// </summary>
        /// <param name="CardNo"></param>
        public void SetCardNo(string CardNo)
        {
            this.SelfEntity.CardNo = CardNo;
        }
        /// <summary>
        /// 返回身份证
        /// </summary>
        /// <returns></returns>
        public string GetCardNo()
        {
            return this.SelfEntity.CardNo;
        }
    }
}
