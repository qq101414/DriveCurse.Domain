﻿using Centa.ZJ.DriveCurse.Domain.Core.DomainObjects;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Centa.ZJ.DriveCurse.Domain.Sys.BusinessObjects
{
    /// <summary>
    /// 用户权限
    /// </summary>
    [Table("EmployeePermission")]
    public class EmployeePermissionEntity : BaseBoEntity
    {
        /// <summary>
        /// 用户登录权限
        /// </summary>
        public bool Land { get; set; }


        public Guid? EmoloyeeKeyId { get; set; }
        public virtual EmployeeEntity Employee { get; set; }

    }

    public class EmployeePermission : BaseObjects
    {
        public EmployeePermissionEntity SelfEntity { get => this.Entity as EmployeePermissionEntity; set => this.Entity = value; }
        public EmployeePermission(EmployeePermissionEntity entity)
        {
            this.Entity = entity;
        }
        /// <summary>
        /// 用户登录权限
        /// </summary>
        public void SetLand(bool land)
        {
            this.SelfEntity.Land = land;
        }
        /// <summary>
        /// 返回登陆权限
        /// </summary>
        /// <returns></returns>
        public bool GetLand()
        {
            return this.SelfEntity.Land;
        }
    }
}
