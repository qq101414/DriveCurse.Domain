﻿using Centa.ZJ.DriveCurse.Domain.Core;
using Centa.ZJ.DriveCurse.Domain.Core.Repository;
using Centa.ZJ.DriveCurse.Domain.Sys.BusinessObjects;
using System;
using System.Collections.Generic;
using System.Text;

namespace Centa.ZJ.DriveCurse.Domain.Sys
{
    public class EmployeeSortCriteria : BoSortCriteria
    {

    }
    public class EmployeeSearchCriteria : BoSearchCriteria
    {

    }

    /// <summary>
    /// Employee领域仓储接口
    /// </summary>
    public interface IEmployeeRepository : IBaseRepository<Employee, EmployeeSearchCriteria, EmployeeSortCriteria>
    {

    }
}
