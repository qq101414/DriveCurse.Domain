﻿using Centa.ZJ.DriveCurse.Domain.Sys.BusinessObjects;
using System;
using System.Collections.Generic;
using System.Text;

namespace Centa.ZJ.DriveCurse.Domain.Sys
{
    public class SysFactory
    {
        public SysFactory() { }

        /// <summary>
        /// 创建一个空Employee
        /// </summary>
        /// <returns></returns>
        public static Employee NewEmployee()
        {
            return new Employee(new EmployeeEntity { KeyId = Guid.NewGuid() });
        }
    }
}
