﻿using System;
using System.Collections.Generic;
using System.Text;
using Autofac;
using Autofac.Extensions.DependencyInjection;
using Centa.ZJ.DriveCurse.Application.Interface.Sys;
using Centa.ZJ.DriveCurse.Application.Sys;
using Centa.ZJ.DriveCurse.Domain.Core;
using Centa.ZJ.DriveCurse.Domain.Core.UnitOfWork;
using Centa.ZJ.DriveCurse.Domain.Sys;
using Centa.ZJ.DriveCurse.Library;
using Centa.ZJ.DriveCurse.Repository.Sys;
using Microsoft.Extensions.DependencyInjection;
//using Centa.ZJ.DriveCurse.Domain.Core;
//using Centa.ZJ.DriveCurse.Domain.Sys;
//using Centa.ZJ.DriveCurse.Repository.Sys;

namespace Centa.ZJ.DriveCurse.Ioc
{
    /// <summary>
    /// 使用autoFac注册
    /// </summary>
    public class IServiceInjection
    {
        public static IContainer AutofacContainer;
        public static void PopulateMvc(IServiceCollection services)
        {
            var bulid = IServiceInjection.Injection();
            bulid.Populate(services);//使用aotufac接管services
            //创建容器.
            AutofacContainer = bulid.Build();
            AutofacBuild.AutofacContainer = AutofacContainer;
        }
        /// <summary>
        /// 并没有完成注册 返回参数需要重新 调用  bulid.Build()；方法
        /// </summary>
        /// <returns></returns>
        public static ContainerBuilder Injection()
        {
            //每个依赖一个实例(Instance Per Dependency)(默认)----InstancePerDependency()
            //单一实例(Single Instance) 单例----SingleInstance()
            //每个生命周期作用域一个实例(Instance Per Lifetime Scope)----InstancePerLifetimeScope()
            //每个匹配的生命周期作用域一个实例(Instance Per Matching Lifetime Scope)----InstancePerMatchingLifetimeScope()
            //每个请求一个实例(Instance Per Request) asp.net web请求----InstancePerRequest()
            //每次被拥有一个实例(Instance Per Owned)----InstancePerOwned()
            //创建容器
            var bulid = new Autofac.ContainerBuilder();
            //AppUnitOfWork : IUnitOfWork
            bulid.RegisterType<SqlServerContext>().As<IDbContext>().InstancePerLifetimeScope();//每个生命周期一个实例
            bulid.RegisterType<AppUnitOfWork>().As<IUnitOfWork>().UsingConstructor(typeof(IDbContext)).InstancePerLifetimeScope();//每个生命周期一个实例
            bulid.RegisterType<SysOnModelCreating>().As<IOnModelCreating>().SingleInstance();//单例模式
            //bulid.RegisterType<EmployeeRepository>().As<IEmployeeRepository>();
            //程序集注入仓储层和接口
            //bulid.RegisterAssemblyTypes(typeof(EmployeeRepository).Assembly, typeof(IEmployeeRepository).Assembly).
            //    Where(x => x.Name.EndsWith("Repository")).AsImplementedInterfaces();
            //bulid.RegisterAssemblyTypes(typeof(EmployeeService).Assembly, typeof(IEmployeeService).Assembly).AsImplementedInterfaces();
            //.Where(x => x.Name.EndsWith("Service"))
            bulid.RegisterType<EmployeeRepository>().As<IEmployeeRepository>().UsingConstructor(typeof(IDbContext)).InstancePerLifetimeScope();//.AsImplementedInterfaces();
            bulid.RegisterType<EmployeeService>().As<IEmployeeService>().InstancePerLifetimeScope().AsImplementedInterfaces();
            return bulid;
        }


    }
}
