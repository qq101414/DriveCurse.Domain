﻿using Autofac;
using System;
using System.Collections.Generic;
using System.Text;

namespace Centa.ZJ.DriveCurse.Library
{
    public class AutofacBuild
    {
        public static IContainer AutofacContainer;

        public static T Resolve<T>()
        {
            return AutofacContainer.Resolve<T>();
        }

        public static IEnumerable<T> ResolveAll<T>()
        {
            return AutofacContainer.Resolve<IEnumerable<T>>();
        }
    }
}
