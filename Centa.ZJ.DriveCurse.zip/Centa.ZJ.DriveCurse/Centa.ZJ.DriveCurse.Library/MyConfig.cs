﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Centa.ZJ.DriveCurse.Library
{
    public class MyConfig
    {
        public string Conn { get; set; }

        public List<string> UserAdmin { get; set; }

        public string WebApiUrl { get; set; }
        public string UploadFile { get; set; }
    }
}
