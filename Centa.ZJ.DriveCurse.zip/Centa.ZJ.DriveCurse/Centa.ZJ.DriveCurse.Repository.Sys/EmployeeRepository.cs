﻿using Centa.ZJ.DriveCurse.Domain.Core;
using Centa.ZJ.DriveCurse.Domain.Core.Repository;
using Centa.ZJ.DriveCurse.Domain.Sys;
using Centa.ZJ.DriveCurse.Domain.Sys.BusinessObjects;
using System;
using System.Collections.Generic;
using System.Text;

namespace Centa.ZJ.DriveCurse.Repository.Sys
{
    public class EmployeeRepository : BaseRepository<Employee, EmployeeEntity, EmployeeSearchCriteria, EmployeeSortCriteria>, IEmployeeRepository
    {

        public EmployeeRepository(IDbContext dbContext) : base(dbContext)
        {

        }

    }
}
