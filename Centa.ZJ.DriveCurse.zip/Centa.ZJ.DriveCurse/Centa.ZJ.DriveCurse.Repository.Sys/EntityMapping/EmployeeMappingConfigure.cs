﻿using Centa.ZJ.DriveCurse.Domain.Core.DomainObjects;
using Centa.ZJ.DriveCurse.Domain.Sys.BusinessObjects;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace Centa.ZJ.DriveCurse.Repository.Sys.EntityMapping
{
    public class EmployeeMappingConfigure : Microsoft.EntityFrameworkCore.IEntityTypeConfiguration<EmployeeEntity>
    {
        public void Configure(EntityTypeBuilder<EmployeeEntity> builder)
        {
            builder.HasKey(x => x.KeyId);
            builder.Property(x => x.Age).HasMaxLength(3).HasAnnotation("年龄", 0);
            builder.Property(x => x.CardNo).IsRequired();
            builder.Property(x => x.CreateTime).IsRequired().HasAnnotation("创建时间", DateTime.Now); ;
            builder.Property(x => x.EmployeeNo).IsRequired();
            builder.Property(x => x.Name).HasMaxLength(10).IsRequired();
            builder.Property(x => x.Sex).HasMaxLength(4).HasAnnotation("性别", "男");
            //一对一关联
            //builder.HasOne(p => p.EmployeePermission).WithOne(p => p.Employee).
            //    HasPrincipalKey<EmployeeEntity>(x => x.PermissionKeyId).
            //    HasForeignKey<EmployeePermissionEntity>(x => x.EmoloyeeKeyId);
            builder.HasOne(p => p.EmployeePermission).WithMany().HasForeignKey(r => r.PermissionKeyId);
        }
    }
}
