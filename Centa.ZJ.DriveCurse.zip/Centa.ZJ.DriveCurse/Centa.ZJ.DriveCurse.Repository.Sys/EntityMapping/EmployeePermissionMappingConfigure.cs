﻿using Centa.ZJ.DriveCurse.Domain.Sys.BusinessObjects;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace Centa.ZJ.DriveCurse.Repository.Sys.EntityMapping
{
    public class EmployeePermissionMappingConfigure : Microsoft.EntityFrameworkCore.IEntityTypeConfiguration<EmployeePermissionEntity>

    {
        public void Configure(EntityTypeBuilder<EmployeePermissionEntity> builder)
        {
            builder.HasKey(x => x.KeyId);
            builder.Property(x => x.Land).IsRequired().HasAnnotation("登陆权限", true);
            builder.Property(x => x.CreateTime).IsRequired().HasAnnotation("创建时间", DateTime.Now);
            //一对一关联
            //builder.HasOne(x => x.Employee).WithOne(x => x.EmployeePermission).
            //    HasPrincipalKey<EmployeePermissionEntity>(x => x.EmoloyeeKeyId).HasForeignKey<EmployeeEntity>(x => x.PermissionKeyId);
        }
    }
}
