﻿using Centa.ZJ.DriveCurse.Domain.Core;
using Centa.ZJ.DriveCurse.Repository.Sys.EntityMapping;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace Centa.ZJ.DriveCurse.Repository.Sys
{
    /// <summary>
    /// EF映射
    /// </summary>
    public class SysOnModelCreating : IOnModelCreating
    {
        public void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new EmployeeMappingConfigure());
            modelBuilder.ApplyConfiguration(new EmployeePermissionMappingConfigure());
        }
    }
}
