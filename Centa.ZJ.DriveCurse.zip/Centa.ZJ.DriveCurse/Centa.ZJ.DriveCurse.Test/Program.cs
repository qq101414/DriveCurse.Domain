﻿using System;

namespace Centa.ZJ.DriveCurse.Test
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
